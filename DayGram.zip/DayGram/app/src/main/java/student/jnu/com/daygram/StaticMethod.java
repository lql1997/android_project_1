package student.jnu.com.daygram;

import android.icu.util.Calendar;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StaticMethod {
    public static String toStrWeek(int week) {
        String week_str="null";
        switch (week % 7) {
            case 0: week_str= "SATURDAY";break;
            case 1: week_str=  "SUNDAY";break;
            case 2: week_str=  "MONDAY";break;
            case 3: week_str=  "TUESDAY";break;
            case 4: week_str=  "WEDNESDAY";break;
            case 5: week_str=  "THURSDAY";break;
            case 6: week_str=  "FRIDAY";break;
        }
        return week_str;
    }
    public static String toStrMoon(int moon){
        String moon_str="null";
        switch(moon){
            case 1:moon_str="JAN";break;
            case 2:moon_str="FEB";break;
            case 3:moon_str="MAR";break;
            case 4:moon_str="APR";break;
            case 5:moon_str="MAY";break;
            case 6:moon_str="JUN";break;
            case 7:moon_str="JUL";break;
            case 8:moon_str="AUG";break;
            case 9:moon_str="SEPT";break;
            case 10:moon_str="OCT";break;
            case 11:moon_str="NOV";break;
            case 12:moon_str="DEC";break;
        }
        return moon_str;
    }
    public static String toStrMoon_all(int moon){
        String moon_str="null";
        switch(moon){
            case 1:moon_str="January";break;
            case 2:moon_str="February";break;
            case 3:moon_str="March";break;
            case 4:moon_str="April";break;
            case 5:moon_str="May";break;
            case 6:moon_str="June";break;
            case 7:moon_str="July";break;
            case 8:moon_str="August";break;
            case 9:moon_str="September";break;
            case 10:moon_str="October";break;
            case 11:moon_str="November";break;
            case 12:moon_str="December";break;
        }
        return moon_str;
    }

    //获取某个月的最大天数
    public static int getMaxDayByYearMonth(int year, int month) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month-1);
        return calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
    }

    //判断某一天是否为周日，输入字符串的格式必须为yyyy-mm-dd
    public static boolean WeekendMethod(int year,int month,int day) {
        DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        String bDate=Integer.toString(year);
        if (month<10)
            bDate=bDate+"-"+"0"+Integer.toString(month);
        else
            bDate=bDate+"-"+Integer.toString(month);
        if (day<10)
            bDate=bDate+"-"+"0"+Integer.toString(day);
        else
            bDate=bDate+"-"+Integer.toString(day);
        Date bdate = null;
        try {
            bdate = format1.parse(bDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar cal = Calendar.getInstance();
        cal.setTime(bdate);
        if(cal.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY)
            return true;
        else
            return false;
    }

    //获取一周内的周几
    public static int getDayofweek(int year,int month,int day){
        Calendar cal = Calendar.getInstance();
        String bDate=Integer.toString(year);
        if (month<10)
            bDate=bDate+"-"+"0"+Integer.toString(month);
        else
            bDate=bDate+"-"+Integer.toString(month);
        if (day<10)
            bDate=bDate+"-"+"0"+Integer.toString(day);
        else
            bDate=bDate+"-"+Integer.toString(day);
//   cal.setTime(new Date(System.currentTimeMillis()));
        if (bDate.equals("")) {
            cal.setTime(new Date(System.currentTimeMillis()));
        }else {
            cal.setTime(new Date(getDateByStr2(bDate).getTime()));
        }
        return cal.get(Calendar.DAY_OF_WEEK);
    }



    public static Date getDateByStr2(String dd)
    {

        SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd");
        Date date;
        try {
            date = sd.parse(dd);
        } catch (ParseException e) {
            date = null;
            e.printStackTrace();
        }
        return date;
    }

}

