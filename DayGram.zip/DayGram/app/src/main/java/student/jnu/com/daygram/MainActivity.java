package student.jnu.com.daygram;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    int year,moon,today;//默认为当天的年月
    HashMap<String,List> database=new HashMap<String, List>();//哈希表数据库，以yyyy-mm为键，动态数组为值保存
    ListView listView;
    HorizontalListView horizontalListView;
    HorizontalListViewAdapter horizontalListViewAdapter;
    diary_collection_operater diary_collection_operater=new diary_collection_operater();
    MyListAdapter myListAdapter;
    ArrayList<diary> data=new ArrayList<diary>();
    Button button_add,button_mon,button_year,button_bian;

    String[] Strmoon={"JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEPT","OCT","NOV","DEC"};
    String[] Strmoontoyear;

    String key;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //初始化保存的哈希表,用于测试，实际运用需要删除下面这行代码即可
        diary_collection_operater.save(MainActivity.this,database);
        //反序列化哈希表读取至database
        database=diary_collection_operater.load(MainActivity.this);
        Calendar calendar=Calendar.getInstance(Locale.CHINA);//获取时间组件//实时修改为打开app的时间
        year=calendar.get(Calendar.YEAR);//默认设置打开app当前年份
        moon=calendar.get(Calendar.MONTH)+1;//默认设置打开app当前月份
        today=calendar.get(Calendar.DAY_OF_MONTH);//默认设置打开app当前日期

        listView=(ListView)findViewById(R.id.listview1);//绑定后才可以使用f5
        listView.setOnItemClickListener(new mItemClick());//注册listview监听事件

        //增加add添加当天日记
        button_add=(Button)findViewById(R.id.button_add);
        button_add.setOnClickListener(new maddClick());

        //注册月份的按钮事件，实现横向listview,over
        button_mon=(Button)findViewById(R.id.button_moon);
        button_mon.setText(StaticMethod.toStrMoon(moon));
        button_mon.setOnClickListener(new mMoonClick());

        //注册年份的按钮事件，实现横向listview,over
        button_year=(Button)findViewById(R.id.button_years);
        button_year.setText(Integer.toString(year));
        button_year.setOnClickListener(new mYearClick());

        //注册变换当月日记浏览界面的点击事件,over
        button_bian=(Button)findViewById(R.id.button_bian);
        button_bian.setOnClickListener(new mBianClick());
        F5();
    }

    //实现变换当月日记浏览界面的点击事件,over
    class mBianClick implements View.OnClickListener{
        boolean flag=true;
        @Override
        public void onClick(View view) {
            if (flag) {
                Toast.makeText(MainActivity.this,"已转换为日记浏览模式",Toast.LENGTH_SHORT).show();
                myListAdapter = new MyListAdapter(data, false);
                listView.setAdapter(myListAdapter);
                flag=false;
            }
            else {
                Toast.makeText(MainActivity.this,"已转换为日记概要模式",Toast.LENGTH_SHORT).show();
                myListAdapter=new MyListAdapter(data,true);
                listView.setAdapter(myListAdapter);
                flag=true;
            }
        }
    }

    //实现点击年份横向按钮的点击事件,over
    class  mYearClick implements View.OnClickListener{
        String[] temp_year=new String[20];
        @Override
        public void onClick(View view) {
            horizontalListView=(HorizontalListView)findViewById(R.id.henglistview);
            Calendar calendar=Calendar.getInstance(Locale.CHINA);//获取时间组件
            int record_year=calendar.get(Calendar.YEAR);
            for (int i=0;i<10;i++){
                temp_year[i]=String.valueOf(record_year);
                record_year-=1;
            }
            horizontalListViewAdapter=new HorizontalListViewAdapter(getApplicationContext(),temp_year);
            horizontalListView.setAdapter(horizontalListViewAdapter);
            horizontalListView.setVisibility(View.VISIBLE);//使横向列表组件可见
            //这里可扩展底下的按钮控件不可见，但是同时要在其他地方使其可见
            horizontalListView.setTranslationZ(10);//置顶按钮组件
            horizontalListView.setOnItemClickListener(new mYearItemClick());
        }
        class mYearItemClick implements AdapterView.OnItemClickListener{
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView tempyear=view.findViewById(R.id.heng_text);
                year=Integer.parseInt(tempyear.getText().toString());
                horizontalListView.setVisibility(View.INVISIBLE);
                F5();
            }
        }
    }
    //实现点击月份横向按钮的点击事件,over
    class mMoonClick implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            horizontalListView=(HorizontalListView) findViewById(R.id.henglistview);
            Calendar calendar=Calendar.getInstance(Locale.CHINA);//获取时间组件
            int mYear=calendar.get(Calendar.YEAR);
            int mMon=calendar.get(Calendar.MONTH)+1;
            if (mYear==year&&mMon==moon){
                Strmoontoyear=new String[mMon];
                for (int i=0;i<mMon;i++)
                    Strmoontoyear[i]=Strmoon[i];
                horizontalListViewAdapter=new HorizontalListViewAdapter(getApplicationContext(),Strmoontoyear);
            }
            else
                horizontalListViewAdapter=new HorizontalListViewAdapter(getApplicationContext(),Strmoon);
            horizontalListView.setAdapter(horizontalListViewAdapter);
            horizontalListView.setVisibility(View.VISIBLE);//使横向列表组件可见
            //这里可扩展底下的按钮控件不可见，但是同时要在其他地方使其可见
            horizontalListView.setTranslationZ(10);//置顶按钮组件
            horizontalListView.setOnItemClickListener(new mMoonitemClice());
        }
        class mMoonitemClice implements AdapterView.OnItemClickListener{
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                moon=i+1;
                horizontalListView.setVisibility(View.INVISIBLE);
                F5();
            }
        }
    }

    //实现add添加当日日记的点击事件,over
    class maddClick implements View.OnClickListener{
        int mYear,mMon,mDay,mWeek;
        @Override
        public void onClick(View view) {
            Intent intent=new Intent();
            intent.setClass(MainActivity.this,secondActivity.class);//关联两个Activity的类文件
            Bundle bundle=new Bundle();
            Calendar calendar=Calendar.getInstance(Locale.CHINA);//获取时间组件
            mYear=calendar.get(Calendar.YEAR);
            mMon=calendar.get(Calendar.MONTH)+1;
            mDay=calendar.get(Calendar.DAY_OF_MONTH);
            mWeek=calendar.get(Calendar.DAY_OF_WEEK);
            bundle.putInt("sign",1);
            bundle.putString("content",null);
            bundle.putString("week",StaticMethod.toStrWeek(mWeek));
            bundle.putString("year",Integer.toString(mYear));
            bundle.putString("mon",Integer.toString(mMon));
            bundle.putString("date",Integer.toString(mDay));
            year=mYear;
            moon=mMon;
            intent.putExtras(bundle);
            startActivityForResult(intent,1);
        }
    }

    //每个listview的点击实现，实现打开另外一个Activity，并传递相关信息
    class mItemClick implements AdapterView.OnItemClickListener
    {
        public void onItemClick(AdapterView<?>arg0,View arg1,int position,long arg3)
        {
            Intent intent=new Intent();
            intent.setClass(MainActivity.this,secondActivity.class);//关联两个Activity的类文件
            Bundle bundle=new Bundle();
            diary temp=data.get(position);
            if (temp==null) {//圆点的情况
                bundle.putInt("sign", 0);
                bundle.putInt("position", position);//圆点中position可以相当于该年该月的日期,不过要记得+1
                bundle.putInt("year", year);
                bundle.putInt("moon", moon);
                intent.putExtras(bundle);
                startActivityForResult(intent,0);
            }
            else {//修改内容的情况
                diary tempdiary=data.get(position);
                bundle.putInt("sign", 2);
                bundle.putInt("position", position);//圆点中position可以相当于该年该月的日期,不过要记得+1
                bundle.putInt("year", year);
                bundle.putInt("moon", moon);
                bundle.putString("content",tempdiary.getContent());
                intent.putExtras(bundle);
                startActivityForResult(intent,2);
            }
        }
    }

    //接受第二个页面返回的相关信息，并同时更新适配器以更新最新日记内容
    protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        switch (requestCode){
            case 0://点击圆点的情况
                if(resultCode==RESULT_OK){
                    String key0=data.getStringExtra("content_1");
                    if (key0==null)
                        break;
                    //添加新内容
                    int position=data.getIntExtra("position",0);
                    myListAdapter.add_upData(key0,StaticMethod.getDayofweek(year,moon,position+1),position);
                    myListAdapter.notifyDataSetChanged();     //刷新
                    Toast.makeText(MainActivity.this,"您修改的信息是："+key0,Toast.LENGTH_SHORT).show();
                }
                break;
            case 1://add跳回情况
                if(resultCode==RESULT_OK){
                    String key1=data.getStringExtra("content_1");
                    //添加新内容
                    int position=data.getIntExtra("position",0);
                    Calendar calendar=Calendar.getInstance(Locale.CHINA);
                    int mWeek=calendar.get(Calendar.DAY_OF_WEEK);
                    myListAdapter.add_upData(key1,mWeek,position);
                    myListAdapter.notifyDataSetChanged();     //刷新
                    Toast.makeText(MainActivity.this,"您修改的信息是："+key1,Toast.LENGTH_SHORT).show();
                }
                break;
            case 2://修改日记
                if(resultCode==RESULT_OK){
                    String key2=data.getStringExtra("content_1");
                    //添加新内容
                    int position=data.getIntExtra("position",0);
                    Calendar calendar=Calendar.getInstance(Locale.CHINA);
                    int mWeek=calendar.get(Calendar.DAY_OF_WEEK);
                    myListAdapter.add_upData(key2,mWeek,position);
                    myListAdapter.notifyDataSetChanged();     //刷新
                    Toast.makeText(MainActivity.this,"您修改的信息是："+key2,Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    //刷新界面,更新日记以year和moon的为准，使用F5前先确保year和moon是所需要查看的时间
    private void F5(){
        button_year.setText(Integer.toString(year));
        button_mon.setText(StaticMethod.toStrMoon(moon));
        key=Integer.toString(year)+"-"+Integer.toString(moon);
        Calendar calendar=Calendar.getInstance(Locale.CHINA);
        if (database.get(key)!=null) {
            //若非空则提取
            data = (ArrayList<diary>) database.get(key);
        }
        else{
            //若为空则新建一个为空的动态数组,并保存到哈希表,同时序列化保存,
            data=new ArrayList<diary>();
            if (year==calendar.get(Calendar.YEAR)&&moon==calendar.get(Calendar.MONTH)+1)
                for (int i=0;i<=today;i++)
                    data.add(null);
            else
                for (int i=0;i<=StaticMethod.getMaxDayByYearMonth(year,moon);i++)
                    data.add(null);
            database.put(Integer.toString(year)+"-"+Integer.toString(moon),data);
            diary_collection_operater.save(MainActivity.this,database);
        }
        myListAdapter=new MyListAdapter(data,true);
        listView.setAdapter(myListAdapter);
    }

    //ListView的适配器
    class MyListAdapter extends BaseAdapter{
        ArrayList<View> itemViews;
        boolean sign;//true则进入有框架的itemview，falus则进入当月日记浏览画面

        public MyListAdapter(ArrayList<diary> diaryArrayList,boolean sign) {
            this.sign = sign;
            itemViews = new ArrayList<View>(diaryArrayList.size());//.size是包括null的
            if (sign) {
                //日记概要模式
                for (int i = 0; i < diaryArrayList.size(); i++)
                    if ( diaryArrayList.get(i) != null && i+1 == diaryArrayList.get(i).getDate()) {
                        itemViews.add(makeItemView(diaryArrayList.get(i).getContent(), StaticMethod.toStrWeek(diaryArrayList.get(i).getWeek()), diaryArrayList.get(i).getDate()));
                    }
                    else
                        itemViews.add(makeItemPointView(StaticMethod.WeekendMethod(year,moon,i+1)));
            }
            else
                //日记浏览模式
                for (int i=0;i<diaryArrayList.size();i++)
                    if (diaryArrayList.get(i)!=null)
                        itemViews.add(makeItemView(diaryArrayList.get(i).getContent(), StaticMethod.toStrWeek(diaryArrayList.get(i).getWeek()), diaryArrayList.get(i).getDate()));

        }
        public View makeItemView(String content,String week,int date){
            LayoutInflater inflater=(LayoutInflater)MainActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View itemview;
            if (sign){//概要模式
                itemview=inflater.inflate(R.layout.list_item,null);
                TextView text_content=(TextView)itemview.findViewById(R.id.text_content);
                TextView text_week=(TextView)itemview.findViewById(R.id.text_week);
                TextView text_date=(TextView)itemview.findViewById(R.id.text_date);
                text_content.setText(content);
                text_date.setText(Integer.toString(date));
                text_week.setText(week.substring(0,3));
                if (week=="SUNDAY")
                    text_date.setTextColor(Color.RED);
            }
            else {//浏览模式
                itemview=inflater.inflate(R.layout.moonview_item,null);
                TextView text_content=(TextView)itemview.findViewById(R.id.moon_content);
                String data;
                if (date<10)
                    data="0"+Integer.toString(date);
                else
                    data=Integer.toString(date);
                if (week=="SUNDAY") {
                    SpannableString spannableString = new SpannableString(data+" "+week+"："+content);
                    spannableString.setSpan(new ForegroundColorSpan(Color.RED), 3, 9, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    text_content.setText(spannableString);
                }
                else
                    text_content.setText(data+week+content);
            }
            return itemview;
        }
        public View makeItemPointView(boolean ifsunday){
            LayoutInflater inflater=(LayoutInflater)MainActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View itemview=inflater.inflate(R.layout.dian_item,null);
            TextView dian=(TextView)itemview.findViewById(R.id.text_dian);
            if (ifsunday)
                dian.setTextColor(Color.RED);
            return itemview;
        }

        @Override
        public int getCount() {
            return itemViews.size();
        }

        @Override
        public Object getItem(int position) {
            return itemViews.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            return itemViews.get(position);
        }

        public void add_upData(String content,int week,int position){//添加新页面
                diary temp_diary=new diary();
                temp_diary.setContent(content);
                if (content==null)
                    return;
                temp_diary.setYear(year);
                temp_diary.setMon(moon);
                temp_diary.setWeek(week);
                temp_diary.setDate(position+1);
                data.set(position,temp_diary);
                key=Integer.toString(year)+"-"+Integer.toString(moon);
                database.put(key,data);
                diary_collection_operater.save(MainActivity.this,database);
                View view=makeItemView(content,StaticMethod.toStrWeek(week),position+1);
                itemViews.set(position,view);

        }
    }
}
