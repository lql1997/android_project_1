package student.jnu.com.daygram;

import android.icu.util.Calendar;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class diary implements Serializable{
    String content;
    int date,week,year,mon;

    public void setContent(String content) {
        this.content = content;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public void setWeek(int week) {
        this.week = week;
    }

    public void setMon(int mon) {
        this.mon = mon;
    }

    public int getDate() {
        return date;
    }

    public int getYear() {
        return year;
    }

    public int getMon() {
        return mon;
    }

    public String getContent() {
        return content;
    }

    public int getWeek() {
        return week;
    }


}
