package student.jnu.com.daygram;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Rect;
import android.icu.text.SimpleDateFormat;
import android.icu.util.TimeZone;
import android.os.Bundle;
import android.text.Editable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import java.util.Date;

public class secondActivity extends Activity {
    TextView textView;
    EditText editText;
    Button button_done, button_time;
    int position;
    String str_content, str_week, str_date, str_mon, str_year;
    int int_year,int_moon;
    int sign;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);
        Bundle bunde = this.getIntent().getExtras();
        sign=bunde.getInt("sign");
        textView = (TextView) findViewById(R.id.time);
        editText = (EditText) findViewById(R.id.edit);
        button_done = (Button) findViewById(R.id.button_done);
        button_time = (Button) findViewById(R.id.button_time);

        switch (sign){
            case 0://圆点
                int_moon=bunde.getInt("moon");
                int_year=bunde.getInt("year");
                position=bunde.getInt("position");
                str_week=StaticMethod.toStrWeek(StaticMethod.getDayofweek(int_year,int_moon,position+1));
                String time=str_week+ "/" + StaticMethod.toStrMoon_all(int_moon) + " " + Integer.toString(position+1)  + "/" + Integer.toString(int_year);
                //设置Sunday红色
                if (str_week=="SUNDAY") {
                    SpannableString spannableString = new SpannableString(time);
                    spannableString.setSpan(new ForegroundColorSpan(Color.RED), 0, 6, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    textView.setText(spannableString);
                }
                else
                    textView.setText(time);
                SpannableString s = new SpannableString("您这一天还没有开始写日记嘞，快快记录你这一天的收获吧！");
                editText.setHint(s);
                    break;

            case 1://add今天的
                str_week = bunde.getString("week");
                str_date = bunde.getString("date");
                str_mon = bunde.getString("mon");
                str_year = bunde.getString("year");
                position=Integer.parseInt(str_date)-1;
                String time1=str_week + "/" + StaticMethod.toStrMoon_all(Integer.parseInt(str_mon)) + " " + str_date + "/" + str_year;
                //设置Sunday红色
                if (str_week=="SUNDAY") {
                    SpannableString spannableString = new SpannableString(time1);
                    spannableString.setSpan(new ForegroundColorSpan(Color.RED), 0, 6, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    textView.setText(spannableString);
                }
                else
                    textView.setText(time1);
                SpannableString s1 = new SpannableString("您这一天还没有开始写日记嘞，快快记录你这一天的收获吧！");
                editText.setHint(s1);
                break;

            case 2://修改日记
                str_content = bunde.getString("content");//日记内容
                int_moon=bunde.getInt("moon");
                int_year=bunde.getInt("year");
                position=bunde.getInt("position");
                str_week=StaticMethod.toStrWeek(StaticMethod.getDayofweek(int_year,int_moon,position+1));
                String time2=str_week+ "/" + StaticMethod.toStrMoon_all(int_moon) + " " + Integer.toString(position+1)  + "/" + Integer.toString(int_year);
                //设置Sunday红色
                if (str_week=="SUNDAY") {
                    SpannableString spannableString = new SpannableString(time2);
                    spannableString.setSpan(new ForegroundColorSpan(Color.RED), 0, 6, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    textView.setText(spannableString);
                }
                else
                    textView.setText(time2);
                editText.setText(str_content);
        }

        button_done.setOnClickListener(new btnclock());
        button_time.setOnClickListener(new mTimeClick());

    }

    class btnclock implements View.OnClickListener {
        public void onClick(View v) {
            onBackPressed();
        }
    }

    public void onBackPressed() {
        Intent intent3 = new Intent();
        switch (sign){
            case 0://圆点
                intent3.putExtra("content_1", editText.getText().toString());
                intent3.putExtra("position", position);
                setResult(RESULT_OK, intent3);
                break;
            case 1://add
                intent3.putExtra("content_1", editText.getText().toString());
                intent3.putExtra("position", position);
                setResult(RESULT_OK, intent3);
                break;
            case 2://
                intent3.putExtra("content_1", editText.getText().toString());
                intent3.putExtra("position", position);
                setResult(RESULT_OK, intent3);
                break;
        }
        super.onBackPressed();
    }

    class mTimeClick implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            SimpleDateFormat df = new SimpleDateFormat("HH:mm");//设置日期格式
            df.setTimeZone(TimeZone.getTimeZone("GMT+08:00")); // 不会受系统时区设置的影响,否则时间可能不准确
            Editable editable = editText.getEditableText();
            int index = editText.getSelectionStart();
            if (index < 0 || index >= editText.length()) {
                editText.append(df.format(new Date()));
            } else {
                editable.insert(index, df.format(new Date()));//光标所在位置插入文字
            }
        }
    }
}
